<?php

namespace App\Repositories\Payment;

use App\Models\Clients;
use App\Repositories\CoreRepository;
use App\Repositories\Interfaces\Payment\StripeInterface;
use App\Models\Transaction as Model;
use Stripe\StripeClient;

class StripeRepository extends CoreRepository implements StripeInterface
{

    public function __construct()
    {
        parent::__construct();
    }

    protected function getModelClass()
    {
        $this->model = Model::class;
    }

    public function createCustomer($params)
    {
        // TODO: Implement createCustomer() method.
    }

    public function setCardToken($params, $key)
    {
        $client = Clients::find($params['client_id']);
        if ($client){
            $stripe = new StripeClient($key);
                $year = \Str::of($params['card_expired'])->after('/');
                $month = \Str::of($params['card_expired'])->before('/');
                try {
                    return $stripe->tokens->create([
                        'card' => [
                            'number' => $params['card_number'],
                            'exp_month' => $month,
                            'exp_year' => $year,
                            'cvc' => $params['card_cvv'],
                        ],
                    ]);
                } catch (\Exception $exception) {
                    return response()->json($exception->getMessage());
                }
        } else {
            return response()->json([
                'success' => 0,
                'msg' => "Client not found!"
            ]);
        }
    }

    public function shopBalanceCharge($params, $key)
    {
            $card = $this->setCardToken($params, $key);
            if ($card && $card->id) {
                $stripe = new StripeClient($key);
                try {
                    return $stripe->charges->create([
                        'amount' => $params['amount'] * 100,
                        'currency' => 'usd',
                        'card' => $card->id,
                        'description' => 'Top up order #'.$params['order_id'],
                    ]);

                } catch (\Exception $exception) {
                    return response()->json($exception->getMessage());
                }
            }

    }

}
