<?php

namespace App\Repositories\Interfaces;

interface DeliveryInterface
{
    public function datatable($array = []);

    public function save($array = []);

}
