<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ExtrasGroupTypes extends Model
{
    protected $table = "product_extra_input_types";
    protected $primaryKey = "id";
}
