<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ShopsRating extends Model
{
    protected $table = "shops_rating";
    protected $primaryKey = "id";
    protected $guarded = [];
}
