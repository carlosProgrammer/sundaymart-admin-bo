<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class OrdersStatus extends Model {
    protected $table = "order_status";
    protected $primaryKey = "id";
    protected $guarded = [];
}
