<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PaymentsStatus extends Model {
    protected $table = "payment_status";
    protected $primaryKey = "id";
    protected $guarded = [];
}
