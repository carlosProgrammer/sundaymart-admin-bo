<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PaymentsMethod extends Model
{
    protected $table = "payment_method";
    protected $primaryKey = "id";
    protected $guarded = [];
}
