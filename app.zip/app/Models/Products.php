<?php


namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Products extends Model
{
    protected $table = "products";
    protected $primaryKey = "id";

    protected $guarded = [];
    const DISCOUNT_TYPE = [
        1 => 'percent',
        2 => 'amount',
    ];

    public function images()
    {
        return $this->hasMany(ProductsImages::class, 'id_product', 'id');
    }

    public function language()
    {
        return $this->hasOne(ProductsLanguage::class, 'id_product', 'id');
    }

    public function languages()
    {
        return $this->hasMany(ProductsLanguage::class, 'id_product', 'id');
    }

    public function discount()
    {
        return $this->hasOneThrough(Discount::class, DiscountProducts::class,  'id_product','id',  'id','id_discount');
    }

    public function coupon()
    {
        return $this->hasOne(CouponProducts::class, 'id_product', 'id');
    }

    public function category()
    {
        return $this->belongsTo(Categories::class, 'id_category', 'id');
    }

    public function shop()
    {
        return $this->belongsTo(Shops::class, 'id_shop', 'id');
    }

    public function comments()
    {
        return $this->hasMany(ProductsComment::class, 'id_product', 'id');
    }

    public function units()
    {
        return $this->belongsTo(Units::class, 'id_unit', 'id');
    }

    public function brands() {
        return $this->belongsTo(Brands::class,"id_brand", "id");
    }

    public function description() {
        return $this->hasMany(ProductsCharacterics::class, "id_product", "id");
    }

    public function extras() {
        return $this->hasMany(ProductExtrasGroup::class, "id_product", "id");
    }


  /*  public function extrasGroup() {
        return $this->hasMany(ProductExtrasGroup::class,"id_product");
    }*/

    public function actualDiscount(){
        return $this->hasOneThrough(Discount::class, DiscountProducts::class,  'id_product','id',  'id','id_discount')
            ->where(['active' => 1, 'is_count_down' => 0])
            ->orWhere(function($query) {
                $query->where('active', 1)
                    ->where('is_count_down', 1)
                    ->whereDate('start_time', '<', now())->whereDate('end_time', '>', now());
            });
    }
}
