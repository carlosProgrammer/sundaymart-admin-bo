<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AdminNotifications extends Model
{
    protected $table = "admin_notifications";
    protected $primaryKey = "id";

    protected $guarded = [];
}
