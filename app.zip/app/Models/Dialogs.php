<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Dialogs extends Model
{
    protected $table = "dialogs";
    protected $primaryKey = "id";
}
