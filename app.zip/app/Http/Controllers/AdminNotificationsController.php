<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\AdminNotifications;
use Illuminate\Support\Facades\Validator;

class AdminNotificationsController extends Controller
{
    public function datatable(Request $request)
    {

    }

    public function delete(Request $request)
    {

    }

    public function get(Request $request)
    {

    }
}
