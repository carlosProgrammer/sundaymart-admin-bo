<?php

namespace App\Http\Controllers\Payment;

use App\Http\Controllers\Controller;
use App\Models\Orders;
use App\Models\ShopPayment;
use App\Repositories\Interfaces\Payment\PaystackRepoInterface;
use App\Repositories\Interfaces\Payment\StripeInterface;
use App\Repositories\Interfaces\ShopPaymentInterface;
use App\Repositories\Interfaces\TransactionInterface;
use App\Traits\ApiResponse;
use Illuminate\Http\Request;

class BasePaymentController extends Controller
{
    use ApiResponse;
    private $shopPaymentRepository, $transactionRepository;
    private $stripeRepository, $paystackRepository;

    /**
     * @param $stripeRepository
     * @param $paystackRepository
     */
    public function __construct(
        ShopPaymentInterface $shopPaymentRepository,
        StripeInterface $stripeRepository,
        PaystackRepoInterface $paystackRepository,
        TransactionInterface $transactionRepository
    )
    {
        $this->shopPaymentRepository = $shopPaymentRepository;
        $this->transactionRepository = $transactionRepository;
        $this->stripeRepository = $stripeRepository;
        $this->paystackRepository = $paystackRepository;
    }

    /**
     *
     *
     */
    public function payment(Request $request){

        $shopPayment = ShopPayment::with('payment')->where(['id_shop' => $request->shop_id, 'id_payment' => $request->payment_id])->first();

        if ($shopPayment) {
            switch ($shopPayment->payment->tag){
                case 'stripe':
                    return $this->stripePayment($request->all(), $shopPayment->secret_id);
                case 'paystack':
                    return $this->paystackPayment($request->all(), $shopPayment->secret_id);
                default:
                    return $this->errorResponse('Payment system not found');
            }
        }
        return $this->errorResponse('Shop payment not found');
    }

    /**
     *
     *
     */
    private function paystackPayment($array, $key){
        $order = Orders::firstWhere('id', $array['order_id']);

        if ($order){
            $payment = $this->paystackRepository->createTransaction($array + ['amount' => $order->total_sum], $key);
            if (isset($payment->status) && $payment->status == 'succeeded') {
                $transaction = $this->setTransaction($array, $payment->data->reference);
                if ($transaction) {
                    return $this->successResponse('Success', ['redirect_url' => $payment->data->authorization_url]);
                } else {
                    return $this->errorResponse('Transaction failed');
                }
            } else {
                return $this->errorResponse($payment);
            }
        } else {
            return $this->errorResponse('Order not found');
        }
    }

    /**
     *
     *
     */
    public function stripePayment($array, $key){
        $order = Orders::firstWhere('id', $array['order_id']);

        if ($order){
            $params = $array + ['amount' => $order->total_sum, 'client_id' => $order->id_user];
            $payment = $this->stripeRepository->shopBalanceCharge($params, $key);

            if (isset($payment->status) && $payment->status == 'succeeded') {
                $transaction = $this->setTransaction($array, $payment->id);
                if ($transaction) {
                    return $this->successResponse('Successes', [
                        'stripe_trans_id' => $payment->id,
                        'receipt_url' => $payment->receipt_url,
                    ]);
                } else {
                    return $this->errorResponse('Transaction failed');
                }
            } else {
                return $this->errorResponse($payment->original);
            }
        } else {
            return $this->errorResponse('Order not found');
        }
    }


    /**
     *
     *
     */
    private function setTransaction($array, $transaction_id){
        $order = Orders::firstWhere('id', $array['order_id']);

        if ($order) {
            $params = [
                'shop_id' => $order->id_shop,
                'client_id' => $order->id_user,
                'order_id'  => $order->id,
                'payment_sys_trans_id'  => $transaction_id,
                'payment_sys_id'  => $array['payment_id'],
                'type'  => 'CREDIT',
                'amount' => $order->total_sum,
                'currency'  => 'usd',
                'perform_time'  => now(),
                'status'  => 1,
                'status_description'  => 'In Process',
            ];

            $this->transactionRepository->createOrUpdate($params);

            return true;
        }
        return false;
    }
}
