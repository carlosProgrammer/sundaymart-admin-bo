<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Repositories\Interfaces\ProductInterface;
use Illuminate\Http\Request;

class ProductController extends Controller
{
    private $productRepository;

    public function __construct(ProductInterface $product)
    {
        $this->productRepository = $product;
    }

    public function save(Request $request)
    {
        return $this->productRepository->createOrUpdate($request->all());
    }

    public function datatable(Request $request)
    {
        return $this->productRepository->datatable($request->all());
    }


    public function get(Request $request)
    {
        return $this->productRepository->get($request->id);
    }

    public function delete(Request $request)
    {
        return $this->productRepository->delete($request->id);
    }

    public function commentsDelete(Request $request)
    {
        return $this->productRepository->deleteComment($request->id);
    }

    public function commentsDatatable(Request $request)
    {
        return $this->productRepository->datatableComment($request->all());
    }

    public function active(Request $request)
    {
        return $this->productRepository->active($request->shop_id);
    }

    public function getTotalProductsCount()
    {
        return $this->productRepository->getProductCount();
    }
}
